package tester2;

public class Order extends Items {

	// Constructor for the Order Item List
	public Order(String prodCode, int quantity, double unitPrice, double total) {
		super(prodCode, quantity, unitPrice, total);
	}
}
