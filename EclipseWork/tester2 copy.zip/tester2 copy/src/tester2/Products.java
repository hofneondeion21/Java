package tester2;

public class Products extends Items {
	// Contructor	
	public Products(String prodCode, String prodName, double unitCost, int stockAvailable) {
		super(prodCode, prodName, unitCost, stockAvailable);
	}
}
